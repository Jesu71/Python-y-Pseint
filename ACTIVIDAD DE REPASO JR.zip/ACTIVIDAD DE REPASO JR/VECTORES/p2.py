# Crear el arreglo con los nombres del ejercicio.
nombres = ["Juan", "Pedro", "María", "Humberto", "Oscar"]

# Imprimir el arreglo listo.
print("El arreglo de nombres es:", nombres)