PizzaBuilder ---construye---> Pizza
               |
               v
      (diferentes métodos para añadir tamaño, ingredientes, etc.)

Pizza
|
v
Tamaño, Ingredientes (queso, pepperoni, champiñones, etc.)
