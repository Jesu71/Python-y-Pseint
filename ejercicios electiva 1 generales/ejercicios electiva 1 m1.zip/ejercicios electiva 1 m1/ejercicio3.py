# Pedir un número entero.
numero = int(input("Por favor, ingresa un número entero: "))
# Verificar si es par o impar.
if numero % 2 == 0:
    print(f"El número {numero} es par.")
else:
    print(f"El número {numero} es impar.")