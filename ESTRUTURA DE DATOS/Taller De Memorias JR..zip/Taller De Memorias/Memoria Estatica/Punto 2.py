# Matriz de identidad de 3x3.
matriz_identidad = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1]
]
# Imprimir la matriz.
for fila in matriz_identidad:
    print(fila)